main(){
int a=3;
int b=2;
a = a +4;
printf(a);
}
