#include <stdio.h>
#include "symboles.h"

int main(){
	init_table();
	add_symbole("a");
	add_symbole("b");
	add_symbole("c");
	
	symbole * mon_symbole;
	get_symbole("c", &mon_symbole);
	printf("MON SYMBOLE EST : %s\n",mon_symbole->nom);
	print();
	enlever_symbole();
	print();
	return 0;
}
